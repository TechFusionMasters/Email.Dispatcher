﻿namespace $safeprojectname$.Constant
{
    internal class AppConstant
    {
        public const string QueueName = "email.dispatcher.send";
    }
}
