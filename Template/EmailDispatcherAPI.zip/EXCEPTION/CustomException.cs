﻿namespace $safeprojectname$.Exception
{
    public sealed class ResourceAlreadyExistsException : System.Exception
    {
        public ResourceAlreadyExistsException(string message) : base(message) {}
    }
}


