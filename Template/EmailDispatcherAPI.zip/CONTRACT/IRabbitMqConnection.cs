﻿using RabbitMQ.Client;

namespace $safeprojectname$.Contract
{
    public interface IRabbitMqConnection
    {
        IConnection Connection { get; }
    }

}
