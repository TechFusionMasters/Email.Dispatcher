﻿using $safeprojectname$.Modal;

namespace $safeprojectname$.Contract
{
    public interface IEmailRepository
    {
        Task<EmailIdempotency?> GetEmailIdempotencyAsync(string idempotencyKey);
        Task<EmailLog> CreateEmailLog(EmailLog emailLog);
        Task<EmailIdempotency> CreateEmailIdempotency(EmailIdempotency emailIdempotency);
        Task<bool> MarkEmailIdempotencyAsPublishedAsync(int id);
    }
}
