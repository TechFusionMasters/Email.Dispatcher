﻿using $safeprojectname$.Contract;
using RabbitMQ.Client;

namespace $safeprojectname$.Service
{
    public sealed class RabbitMqConnection : IRabbitMqConnection
    {
        public IConnection Connection { get; private set; } = default!;

        internal void SetConnection(IConnection connection)
        {
            Connection = connection;
        }
    }

}