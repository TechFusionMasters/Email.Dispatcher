﻿
namespace $safeprojectname$.Contract
{
    public interface IEmailService
    {
        Task<bool> RescheduleFailedMailsToSend();
    }
}
