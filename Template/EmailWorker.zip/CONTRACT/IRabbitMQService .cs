﻿using $safeprojectname$.Modal;

namespace $safeprojectname$.Contract
{
    public interface IRabbitMQService
    {
        Task CreateConnection(CancellationToken cancellationToken);
        Task InsertMessageToRabbitMQ(EmailIdempotency emailIdempotency, string queueName);
    }
}
