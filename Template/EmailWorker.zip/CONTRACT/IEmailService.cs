﻿using $safeprojectname$.Dto;

namespace $safeprojectname$.Contract
{
    public interface IEmailService
    {
        Task SendEmail(RabitMQDto message);
    }
}
