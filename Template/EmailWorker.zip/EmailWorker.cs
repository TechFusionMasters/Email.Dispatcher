using $safeprojectname$.Contract;

namespace $safeprojectname$
{
    public class $safeprojectname$ : BackgroundService
    {
        private IRabbitMQService _rabbitMQService;

        public $safeprojectname$(IRabbitMQService rabbitMQService)
        {
            _rabbitMQService = rabbitMQService;
        }

        protected override async Task ExecuteAsync(CancellationToken cancellationToken)
        {
            if (cancellationToken.IsCancellationRequested) return;
            await _rabbitMQService.CreateConnection(cancellationToken);
        }
    }
}
