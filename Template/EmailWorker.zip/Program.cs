using EmailRetryScheduler.Dto;
using $safeprojectname$.Contract;
using $safeprojectname$.Data;
using $safeprojectname$.Dto;
using $safeprojectname$.Repository;
using $safeprojectname$.Service;
using Microsoft.Extensions.Configuration;

namespace $safeprojectname$
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = Host.CreateApplicationBuilder(args);

            builder.Services.AddDbContext<AppDBContext>();
            builder.Services.AddScoped<IEmailRepository, EmailRepository>();
            builder.Services.AddScoped<IEmailService, EmailService>();
            builder.Services.Configure<RabbitMQConfig>(builder.Configuration.GetSection("RabbitMQ"));
            builder.Services.Configure<RetryPolicyOptions>(builder.Configuration.GetSection("RetryPolicy"));
            builder.Services.Configure<MailConfig>(builder.Configuration.GetSection("MailConfig"));
            builder.Services.AddSingleton<IRabbitMQService, RabbitMQService>();
            builder.Services.AddHostedService<$safeprojectname$>();


            var host = builder.Build();
            host.Run();
        }
    }
}