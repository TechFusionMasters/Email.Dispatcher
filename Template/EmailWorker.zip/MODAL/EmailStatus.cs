﻿using System.ComponentModel.DataAnnotations;

namespace $safeprojectname$.Modal
{
    public class EmailStatus
    {
        [Key]
        public int Id { get; set; }
        public string Status { get; set; }
    }
}
